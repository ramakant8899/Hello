package com.coursemanagesystem.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coursemanagesystem.apiresponce.ApiResponce;
import com.coursemanagesystem.entities.CourseCart;
import com.coursemanagesystem.services.CartService;

@RestController
public class CartController 
{
	
	@Autowired
	CartService cartServ;
	
	
	@GetMapping("/cart")
	public ResponseEntity<List<CourseCart>> bill() 
	{
		return ResponseEntity.ok(cartServ.details());
	}

	@PostMapping("/cart")
	public ResponseEntity<CourseCart> saveCart(@RequestBody CourseCart cart) 
	{
	  return new ResponseEntity<>(cartServ.saveAllCourseCart(cart),HttpStatus.OK);
    }

	@DeleteMapping("/cart/{id}")
	public ResponseEntity<ApiResponce> deleteCartById(@PathVariable long id)
	{
		 this.cartServ.deleteCartById(id);
		 return new ResponseEntity<ApiResponce>(new ApiResponce("Cart Deleted Successfully", true),HttpStatus.OK);	
	}
	
	@PutMapping("/addtocart")
	public ResponseEntity<Object> addTOCart(@RequestParam  CourseCart crt) 
	{
		return ResponseEntity.ok(cartServ.updateCart(crt));
	}

	
}
