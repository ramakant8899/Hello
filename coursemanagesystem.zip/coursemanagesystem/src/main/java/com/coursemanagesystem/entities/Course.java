package com.coursemanagesystem.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Data
@NoArgsConstructor
@ToString
@Entity


public class Course 
{
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	int id;
	@Column(length=20)
	@NotEmpty
	@Size(min=1, message="Course Name must be min of 1 characters...")
	String courseName;
	@Column(length=50)
	@NotEmpty(message="Fillup The Course Details")
	String courseDescription;
	@Column(length=10)
	@NotEmpty(message="Fillup The Course Time Duration")
	String courseDuration;
	@NotNull(message="Fillup The Course Fee")
	int fee;
	String image;
	
	public Course() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Course(int id,
			@NotEmpty @Size(min = 1, message = "Course Name must be min of 1 characters...") String courseName,
			@NotEmpty(message = "Fillup The Course Details") String courseDescription,
			@NotEmpty(message = "Fillup The Course Time Duration") String courseDuration,
			@NotNull(message = "Fillup The Course Fee") int fee, String image) 
	{
		super();
		this.id = id;
		this.courseName = courseName;
		this.courseDescription = courseDescription;
		this.courseDuration = courseDuration;
		this.fee = fee;
		this.image = image;
	}
	
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getCourseName() 
	{
		return courseName;
	}
	public void setCourseName(String courseName) 
	{
		this.courseName = courseName;
	}
	public String getCourseDescription()
	{
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) 
	{
		this.courseDescription = courseDescription;
	}
	public String getCourseDuration() 
	{
		return courseDuration;
	}
	public void setCourseDuration(String courseDuration)
	{
		this.courseDuration = courseDuration;
	}
	public int getFee() 
	{
		return fee;
	}
	public void setFee(int fee) 
	{
		this.fee = fee;
	}
	public String getImage()
	{
		return image;
	}
	public void setImage(String image) 
	{
		this.image = image;
	}

	@Override
	public String toString() 
	{
		return "Course [id=" + id + ", courseName=" + courseName + ", courseDescription=" + courseDescription
				+ ", courseDuration=" + courseDuration + ", fee=" + fee + ", image=" + image + "]";
	}
		
}
