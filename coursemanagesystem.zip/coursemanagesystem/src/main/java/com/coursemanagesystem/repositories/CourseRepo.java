package com.coursemanagesystem.repositories;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.coursemanagesystem.entities.Course;


public interface CourseRepo extends JpaRepository<Course, Integer> 
{

	Optional<Course> findById(Integer id);

	//Optional<Course> findByName(Course courseName);

//	List<Course> findCourseByName(String courseName);

//	Optional<Course> findByName(Course courseName);
	
//	List<Course>getByUserApply(UserApply userapply);
//	List<Course>getByAdmin(Admin admin);
	
}
