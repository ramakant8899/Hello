package com.coursemanagesystem.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.coursemanagesystem.entities.Admin;
import com.coursemanagesystem.repositories.AdminRepo;

@Service
public class AdminService 
{
	@Autowired
	AdminRepo admRepo;

	public Object getAllAdmin() 
	{
		List<Admin> allAdmin= this.admRepo.findAll();
		return allAdmin;
	}

	public Admin saveAllAdmin(Admin admin) 
	{
		Admin saveAll= this.admRepo.save(admin);
		return saveAll;
	}

	public Admin updateAdmin(@Valid Admin admin) 
	{
		Admin updateAll= this.admRepo.save(admin);
		return updateAll;
	}

	
}
