package com.coursemanagesystem;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.coursemanagesystem.repositories.AdminRepo;
import com.coursemanagesystem.repositories.CourseRepo;
import com.coursemanagesystem.repositories.UserApplyRepo;

@SpringBootTest
class CoursemanagesystemApplicationTests 
{

	@Autowired
	private CourseRepo courseRepo;
	@Autowired
	private AdminRepo adminRepo;
	@Autowired
	private UserApplyRepo useappRepo;
	
	@Test
	public void courserepoTest()
	{
		String className = this.courseRepo.getClass().getName();
		String packageName = this.courseRepo.getClass().getPackageName();
		System.out.println(className);
		System.out.println(packageName);	
	}
	
	@Test
	public void adminrepoTest()
	{
		String className = this.adminRepo.getClass().getName();
		String packageName = this.adminRepo.getClass().getPackageName();
		System.out.println(className);
		System.out.println(packageName);	
	}
	
	@Test
	public void userrepoTest()
	{
		String className = this.useappRepo.getClass().getName();
		String packageName = this.useappRepo.getClass().getPackageName();
		System.out.println(className);
		System.out.println(packageName);	
	}

}
