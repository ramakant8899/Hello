package com.coursemanagesystem.controllers;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.coursemanagesystem.entities.UserApply;
import com.coursemanagesystem.services.UserApplyService;

@RestController
public class UserApplyController 
{
	@Autowired
	UserApplyService useappServ;
	
	@GetMapping("/user")
	public ResponseEntity<Object> getAllUser()
	{
		return ResponseEntity.ok(useappServ.getAllUser());
	}
	
	@PostMapping("/user")
	public ResponseEntity<UserApply> saveAllUser(@Valid @RequestBody UserApply apply)
	{
		return new ResponseEntity<UserApply>(useappServ.saveAllUser(apply),HttpStatus.CREATED);
	}
	
}
