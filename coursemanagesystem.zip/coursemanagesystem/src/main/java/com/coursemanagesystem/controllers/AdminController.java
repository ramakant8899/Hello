package com.coursemanagesystem.controllers;




import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.coursemanagesystem.entities.Admin;
import com.coursemanagesystem.services.AdminService;

@RestController
public class AdminController 
{
	@Autowired
	AdminService admServ;
	
	@GetMapping("/admin")
	public ResponseEntity<Object> getAllAdmin()
	{
		return ResponseEntity.ok(admServ.getAllAdmin());
	}
	
	@PostMapping("/admin")
	public ResponseEntity<Admin> saveAllAdmin(@Valid @RequestParam Admin admin)
	{
		return new ResponseEntity<Admin>(admServ.saveAllAdmin(admin),HttpStatus.CREATED);
	}
  
	@PutMapping("/updadmin")
	public ResponseEntity<Admin> updateAdmin(@Valid @RequestBody Admin admin)
	{
		return ResponseEntity.ok(admServ.updateAdmin(admin));	
	}
	

}
