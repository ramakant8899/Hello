package com.coursemanagesystem.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.coursemanagesystem.entities.UserApply;
import com.coursemanagesystem.repositories.UserApplyRepo;

@Service
public class UserApplyService 
{
	@Autowired
	UserApplyRepo useappRepo;

	public Object getAllUser() 
	{
		List<UserApply> allUser= this.useappRepo.findAll();
		return allUser;
	}

	public UserApply saveAllUser(@Valid UserApply apply) 
	{
		UserApply saveAll= this.useappRepo.save(apply);
		return saveAll;
	}

	
}
