package com.coursemanagesystem.repositories;

import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.coursemanagesystem.entities.CourseCart;


@Repository
public interface CartRepo extends JpaRepository<CourseCart, Long> 
{
	
	Optional<CourseCart> findById(long id);
}
