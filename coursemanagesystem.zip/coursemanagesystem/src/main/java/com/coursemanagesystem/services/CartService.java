package com.coursemanagesystem.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coursemanagesystem.entities.CourseCart;
import com.coursemanagesystem.exceptions.CartItemNotExistException;
import com.coursemanagesystem.repositories.CartRepo;

@Service
public class CartService 
{
	@Autowired
	CartRepo cartRepo;

	public List<CourseCart> details() 
	{
		  return cartRepo.findAll();
	}

	public CourseCart saveAllCourseCart(CourseCart cart) 
	{
		cartRepo.save(cart);
        return cart;
	}

	public String saveToCart(CourseCart c)
	{
		 cartRepo.save(c);
	     return "Add to Cart successfyully";
	}

	public void deleteCartById(long id)
	{
		 CourseCart deleteCart=this.cartRepo.findById(id).orElseThrow(()-> new CartItemNotExistException("CourseCart", "Id", id));
		 this.cartRepo.delete(deleteCart);	
	}

	public Object updateCart(CourseCart crt) 
	{
		CourseCart updateCart= this.cartRepo.save(crt);
		return updateCart;
	}

}
