package com.coursemanagesystem.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@ToString
public class CourseCart 
{	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    long id;
	    String courseName;
	    String courseDescription;
	    String courseDuration;
	    int fee;
	    String image;
	    double quantity;
	    double total;
		
	    public CourseCart() 
	    {
			super();
			// TODO Auto-generated constructor stub
		}

		public CourseCart(long id,String courseName, String courseDescription, String courseDuration, int fee,
				String image, double quantity, double total) 
		{
			super();
			this.id = id;
			this.courseName = courseName;
			this.courseDescription = courseDescription;
			this.courseDuration = courseDuration;
			this.fee = fee;
			this.image = image;
			this.quantity = quantity;
			this.total = total;
		}

		public long getId() 
		{
			return id;
		}

		public void setId(int id) 
		{
			this.id = id;
		}

		
		public String getCourseName() 
		{
			return courseName;
		}

		public void setCourseName(String courseName) 
		{
			this.courseName = courseName;
		}

		public String getCourseDescription() 
		{
			return courseDescription;
		}

		public void setCourseDescription(String courseDescription)
		{
			this.courseDescription = courseDescription;
		}

		public String getCourseDuration() 
		{
			return courseDuration;
		}

		public void setCourseDuration(String courseDuration) 
		{
			this.courseDuration = courseDuration;
		}

		public int getFee() 
		{
			return fee;
		}

		public void setFee(int fee) 
		{
			this.fee = fee;
		}

		public String getImage() 
		{
			return image;
		}

		public void setImage(String image) 
		{
			this.image = image;
		}

		public double getQuantity() 
		{
			return quantity;
		}

		public void setQuantity(double quantity) 
		{
			this.quantity = quantity;
		}

		public double getTotal() 
		{
			return total;
		}

		public void setTotal(double total) 
		{
			this.total = total;
		}

		@Override
		public String toString() 
		{
			return "CourseCart [id=" + id + ", courseName=" + courseName + ", courseDescription="
					+ courseDescription + ", courseDuration=" + courseDuration + ", fee=" + fee + ", image=" + image
					+ ", quantity=" + quantity + ", total=" + total + "]";
		}    	    
}
