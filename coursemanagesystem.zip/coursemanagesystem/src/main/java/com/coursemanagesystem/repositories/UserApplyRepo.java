package com.coursemanagesystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coursemanagesystem.entities.UserApply;

public interface UserApplyRepo extends JpaRepository<UserApply, String>
{
	
}
