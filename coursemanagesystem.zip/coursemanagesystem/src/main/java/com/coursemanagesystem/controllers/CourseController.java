package com.coursemanagesystem.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coursemanagesystem.apiresponce.ApiResponce;
import com.coursemanagesystem.entities.Course;
import com.coursemanagesystem.services.CourseService;



@RestController

public class CourseController 
{
	@Autowired
	CourseService courseServ;
	
	@GetMapping("/course")
	public ResponseEntity<List<Course>> getAllCourses()
	{
		return ResponseEntity.ok(courseServ.getAllCourses());
	}

	@GetMapping("/course/{id}")
	public ResponseEntity<Course> getCourseById(@PathVariable Integer id)
	{
		return ResponseEntity.ok(courseServ.getCourseById(id));
		
	}
	/*
	 * @GetMapping("/course/{courseName}") public ResponseEntity<Course>
	 * getCourseByName(@PathVariable Course courseName) { return
	 * ResponseEntity.ok(courseServ.getCourseByName(courseName)); }
	 */
//	@GetMapping("/course/{courseName}")
//	public List<Course> getAllCourseByName(@PathVariable("courseName") String courseName)
//	{
//		return courseServ.findAllByName(courseName);
//	}
	
	@PostMapping("/course")
	public ResponseEntity<Course> saveAllCourse(@Valid @RequestBody Course course)
	{
		return new ResponseEntity<>(courseServ.saveAllCourse(course), HttpStatus.CREATED);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Course> updateCourse(@Valid @RequestBody Course course)
	{
		return ResponseEntity.ok(courseServ.updateCourse(course));
		
	}
	
	@DeleteMapping("/course/{id}")
	public ResponseEntity<ApiResponce> deleteById(@PathVariable Integer id)
	{
		 this.courseServ.deleteById(id);
		 return new ResponseEntity<ApiResponce>(new ApiResponce("Course Deleted Successfully", true),HttpStatus.OK);	
	}

}
