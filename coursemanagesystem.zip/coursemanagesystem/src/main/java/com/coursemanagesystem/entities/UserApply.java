package com.coursemanagesystem.entities;




import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Data
@Entity
@NoArgsConstructor
@Getter
@Setter
public class UserApply 
{	
	@NotEmpty
	private String userName;
	@Id
	@Email
	private String email;
	@NotEmpty
	private String qualification;
	@NotEmpty(message="Invalid Mobile No....")
	private String phoneno;
	@NotEmpty
	private String address;
	@Column(length=20)
	private Date addedDate;

	public UserApply() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public UserApply(@NotEmpty String userName, @Email String email, @NotEmpty String qualification,
			@NotNull String phoneno, @NotEmpty String address, Date addedDate) 
	{
		super();
		this.userName = userName;
		this.email = email;
		this.qualification = qualification;
		this.phoneno = phoneno;
		this.address = address;
		this.addedDate = addedDate;
	}

	public String getUserName() 
	{
		return userName;
	}

	public void setUserName(String userName) 
	{
		this.userName = userName;
	}

	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}

	public String getQualification()
	{
		return qualification;
	}

	public void setQualification(String qualification) 
	{
		this.qualification = qualification;
	}

	public String getPhoneno() 
	{
		return phoneno;
	}

	public void setPhoneno(String phoneno) 
	{
		this.phoneno = phoneno;
	}

	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public Date getAddedDate() 
	{
		return addedDate;
	}

	public void setAddedDate(Date addedDate) 
	{
		this.addedDate = addedDate;
	}

	@Override
	public String toString() 
	{
		return "UserApply [userName=" + userName + ", email=" + email + ", qualification=" + qualification
				+ ", phoneno=" + phoneno + ", address=" + address + ", addedDate=" + addedDate + "]";
	}
}
